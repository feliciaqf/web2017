(function(){
	var REQ = {
        send: function(action, url, params, callback) {
            var xhr = new XMLHttpRequest();
            xhr.open(action, url, true);
            xhr.setRequestHeader("Content-type", "application/json");
            xhr.onreadystatechange = function(xhrevt) {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    callback && callback(xhr.responseText);
                }
            }
            xhr.send(JSON.stringify(params));
            return xhr;
        }
    }
    var Neo4jREQ = {
        send: function(action, url, params, callback) {
            REQ.send(action, url, params, function(res) {
                res = typeof res === 'string' ? JSON.parse(res) : res;
                if (res.errors.length) {
                    alert('系统异常！');
                    console.log(res.errors);
                    return;
                }
                callback(res.results);
            })
        }
    }
    var NodesREQ = {
        send: function(action, url, params, callback) {
            Neo4jREQ.send(action, url, params, function(res) {
                callback && callback(res[0].data);
            })
        }
    }
})