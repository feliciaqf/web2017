(function() {
    var serverPath = 'http://10.20.21.103:7474/';
    var REQ = {
        send:function(action,url,params,callback){
            var xhr = new XMLHttpRequest();
            xhr.open(action, url, true);
            xhr.setRequestHeader("Content-type","application/json");
            xhr.onreadystatechange = function(xhrevt){
                if(xhr.readyState==4 && xhr.status==200){
                   callback && callback(xhr.responseText); 
                }
            }
            xhr.send(JSON.stringify(params));
            return xhr;
        }
    }
    var Neo4jREQ = {
        send:function(action,url,params,callback){
            REQ.send(action,url,params,function(res){
                res = typeof res === 'string'?JSON.parse(res):res;
                if(res.errors.length){
                    layer.alert('系统异常！');
                    console.log(res.errors);
                    return;
                }
                callback(res.results);
            })
        }
    }
    var NodesREQ = {
        send:function(action,url,params,callback){
            Neo4jREQ.send(action,url,params,function(res){
                callback && callback(res[0].data);
            })
        }
    }

    //获取url参数值
    function getUrlParamValue(name, url) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        var r = window.location.search.substr(1).match(reg);
        if (url) {
            r = url.split("?")[1].match(reg);
        }
        if (r != null) return unescape(r[2]);
        return null;
    }

    function collapse(d) {
        if (d.children) {
            d._children = d.children
            d._children.forEach(collapse)
            d.children = null
        }
    }
    var CONST_COLORS = ['black','#00378d', '#0f9561', '#00a0e9',  '#996c32', '#eca22b', '#f4e026', '#8fc41e', '#9e7cb6', '#ea68a2','#51bdbd'];
    var CONST_COLORS2 = ['#009cde','#9e7cb6','#ea68a2','#8fc41e'];
    var CONST_K = 1;
    var CONST_MAXR = 8;
    var CONST_MAXGANGLE = 90;
    var CONST_HIGHLIGHTCOLORS = ['red','#e43c1d'];
    //关系信息
    var GLOBAL_KEYINFOS = [
        {
            "key": "root",
            "value": "region_name",
            "name": "区局",
            "keyFields": [
                "region_name"
            ]
        },
        {
            "key": "br_equip",
            "value": "br_equip_name",
            "name": "BR",
            "fixFields": {
                "br_equip_no": "equip_no"
            },
            "keyFields": [
                "br_region_name",
                "br_subregion_name",
                "br_site_name",
                "br_room_name",
                "br_equip_no",
                "br_equip_name",
                "br_equip_life",
                "br_usefor",
                "br_usable_num"
            ]
        },
        {
            "key": "bas_equip",
            "value": "bas_equip_name",
            "name": "BAS",
            "fixFields": {
                "bas_equip_no": "equip_no"
            },
            "keyFields": [
                "bas_region_name",
                "bas_subregion_name",
                "bas_site_name",
                "bas_room_name",
                "bas_equip_type",
                "bas_equip_no",
                "bas_equip_name",
                "bas_equip_life"
            ]
        },
        {
            "key": "ipa_equip",
            "value": "up_olt_equip_name",
            "name": "IP服务器",
            "fixFields": {
                "up_olt_equip_no": "equip_no"
            },
            "keyFields": [
                "up_olt_region_name",
                "up_olt_subregion_name",
                "up_olt_site_name",
                "up_olt_room_name",
                "up_olt_equip_type",
                "up_olt_equip_no",
                "up_olt_equip_name",
                "up_olt_equip_life",
                "up_olt_usefor",
                "up_olt_usable_num"
            ]
        },
        {
            "key": "olt_equip",
            "value": "olt_equip_name",
            "name": "OLT",
            "fixFields": {
                "olt_equip_no": "equip_no"
            },
            "keyFields": [
                "olt_region_name",
                "olt_subregion_name",
                "olt_site_name",
                "olt_room_name",
                "olt_equip_no",
                "olt_equip_name",
                "olt_equip_life",
                "olt_usefor",
                "olt_usable_num",
                "olt_bdwidth_sum_a",
                "olt_bdwidth_sum_z"
            ]
        },
        {
            "key": "obd1_equip",
            "value": "obd1_equip_name",
            "name": "一级OBD",
            "fixFields": {
                "obd1_equip_no": "equip_no"
            },
            "keyFields": [
                "obd1_region_name",
                "obd1_subregion_name",
                "obd1_site_name",
                "obd1_room_name",
                "obd1_equip_no",
                "obd1_equip_name",
                "obd1_equip_life",
                "obd1_usefor",
                "obd1_usable_num"
            ]
        },
        {
            "key": "obd2_equip",
            "value": "obd2_equip_name",
            "name": "二级OBD",
            "fixFields": {
                "obd2_equip_no": "equip_no"
            },
            "keyFields": [
                "obd2_region_name",
                "obd2_subregion_name",
                "obd2_site_name",
                "obd2_room_name",
                "obd2_equip_no",
                "obd2_equip_name",
                "obd2_equip_life",
                "obd2_usefor",
                "obd2_usable_num"
            ]
        },
        {
            "key": "onu_equip",
            "value": "onu_equip_name",
            "name": "ONU设备",
            "fixFields": {
                "onu_equip_no": "equip_no"
            },
            "keyFields": [
                "onu_region_name",
                "onu_subregion_name",
                "onu_site_name",
                "onu_room_name",
                "onu_equip_no",
                "onu_equip_name",
                "onu_equip_life",
                "onu_usefor"
            ]
        },
        {
            "key": "ont_equip",
            "value": "ont_equip_name",
            "name": "ONT设备",
            "fixFields": {
                "ont_equip_no": "equip_no"
            },
            "keyFields": [
                "ont_equip_no",
                "ont_equip_name",
                "ont_usefor"
            ]
        },
        {
            "key": "prod_inst",
            "value": "prod_inst_num",
            "name": "终端",
            "keyFields": [
                "prod_inst_num",
                "family_address",
                "install_address",
                "prod__region_name",
                "grid_code",
                "user_name",
                "user_type",
                "user_contact",
                "prod_time",
                "prod_name",
                "prod_start_time",
                "prod_bandwith",
                "prod_name",
                "prod_code"
            ]
        }
    ];
    var GLOBAL_CIRINFOS = {
        "fixFields": {
            // "equ_id_a":"_equip_id",
            // "equ_name_a": "_equip_name",
            // "equ_no_a":'equip_no',
            // "equ_region_a":"_region_name",
            // "port_assemtcode_a":"_port_assemtcode",
            // "port_assemtname_a":"_port_assemtcode",
            // "equ_id_z":"_equip_id",
            // "equ_name_z": "_equip_name",
            // "equ_no_z":'equip_no',
            // "equ_region_z":"_region_name",
            // "port_assemtcode_z":"_port_assemtcode",
            // "port_assemtname_z":"_port_assemtcode",
        },
        "keyFields": [
            "cir_id",
            "cir_no",
            "cir_type",
            "cir_status",
            "equ_id_a",
            "equ_name_a",
            "equ_no_a",
            "equ_region_a",
            "port_assemtcode_a",
            "port_assemtname_a",
            "equ_id_z",
            "equ_name_z",
            "equ_no_z",
            "port_assemtcode_z",
            "port_assemtname_z"
        ]
    }
    var GLOBAL_ROUTERINFOS = {
        "fixFields": {
            "rt_port_no_a":"rt_port_no",
            "rt_port_name_a":"rt_port_name",
            "rt_port_assemtcode_a":"rt_port_assemtcode",
            "rt_port_name_a":"rt_port_name",
            "rt_port_no_z":"rt_port_no",
            "rt_port_name_z":"rt_port_name",
            "rt_port_assemtcode_z":"rt_port_assemtcode"
        },
        "keyFields": [
            "rt_port_no_a",
            "rt_port_name_a",
            "rt_port_assemtcode_a",
            "rt_port_no_z",
            "rt_port_name_z",
            "rt_port_assemtcode_z",
            "link_type",
            "optic_no",
            "optic_1",
            "optic_2",
            "cir_staus"
        ]
    }
    var GLOALROUTERNODES = {
        "keyFields": [
            "rt_port_no",
            "rt_port_name",
            "rt_port_assemtcode"
        ]
    }
    var GLOBAL_KEYMAPPINGS = {
        relation: {
            "br_equip_id": "BR设备id",
            "br_region_name": "BR设备区局",
            "br_subregion_name": "BR设备行政分局",
            "br_site_name": "BR设备站点",
            "br_room_name": "BR设备机房",
            "br_equip_type": "BR设备类型",
            "br_equip_no": "BR设备编号",
            "br_equip_name": "BR设备名称",
            "br_equip_life": "BR设备生命周期",
            "br_usefor": "BR设备用途",
            "br_usable_num": "BR设备可用端口数",
            "bas_equip_id": "BASid",
            "bas_region_name": "BAS区局",
            "bas_subregion_name": "BAS行政分局",
            "bas_site_name": "BAS站点",
            "bas_room_name": "BAS机房",
            "bas_equip_type": "BAS类型",
            "bas_equip_no": "BAS设备编号",
            "bas_equip_name": "BAS设备名称",
            "bas_equip_life": "BAS生命周期",
            "bas_usefor": "BAS设备用途",
            "bas_usable_num": "BAS可用端口数",
            "up_olt_equip_id": "IP服务器id",
            "up_olt_region_name": "IP服务器区局",
            "up_olt_subregion_name": "IP服务器行政分局",
            "up_olt_site_name": "IP服务器站点",
            "up_olt_room_name": "IP服务器机房",
            "up_olt_equip_type": "IP服务器类型",
            "up_olt_equip_no": "IP服务器编号",
            "up_olt_equip_name": "IP服务器名称",
            "up_olt_equip_life": "IP服务器生命周期",
            "up_olt_usefor": "IP服务器用途",
            "up_olt_usable_num": "IP服务器可用端口数",
            "olt_equip_id": "OLTid",
            "olt_region_name": "OLT区局",
            "olt_subregion_name": "OLT行政分局",
            "olt_site_name": "OLT站点",
            "olt_room_name": "OLT机房",
            "olt_equip_no": "OLT设备编号",
            "olt_equip_name": "OLT设备设备名称",
            "olt_equip_life": "OLT生命周期",
            "olt_usefor": "OLT设备用途",
            "olt_usable_num": "OLT可用端口数",
            "olt_bdwidth_sum_a": "OLT上联占用总带宽",
            "olt_bdwidth_sum_z": "OLT下联占用总带宽",
            "obd1_equip_id": "一级OBDid",
            "obd1_region_name": "一级OBD区局",
            "obd1_subregion_name": "一级OBD行政分局",
            "obd1_site_name": "一级OBD站点",
            "obd1_room_name": "一级OBD机房",
            "obd1_equip_no": "一级OBD设备编号",
            "obd1_equip_name": "一级OBD设备设备名称",
            "obd1_equip_life": "一级OBD生命周期",
            "obd1_usefor": "一级OBD设备用途",
            "obd1_usable_num": "一级OBD可用端口数",
            "obd2_equip_id": "二级OBDid",
            "obd2_region_name": "二级OBD区局",
            "obd2_subregion_name": "二级OBD行政分局",
            "obd2_site_name": "二级OBD站点",
            "obd2_room_name": "二级OBD机房",
            "obd2_equip_no": "二级OBD设备编号",
            "obd2_equip_name": "二级OBD设备名称",
            "obd2_equip_life": "二级OBD生命周期",
            "obd2_usefor": "二级OBD设备用途",
            "obd2_usable_num": "二级OBD可用端口数",
            "onu_equip_id": "ONUid",
            "onu_region_name": "ONU区局",
            "onu_subregion_name": "ONU行政分局",
            "onu_site_name": "ONU站点",
            "onu_room_name": "ONU机房",
            "onu_equip_no": "ONU设备编号",
            "onu_equip_name": "ONU设备设备名称",
            "onu_equip_life": "ONU生命周期",
            "onu_usefor": "ONU设备用途",
            "ont_equip_id": "ONTid",
            "ont_equip_no": "ONT设备编号",
            "ont_equip_name": "ONT设备名称",
            "ont_usefor": "ONT设备用途",
            "port_code": "端口拼装编码",
            "port_name": "端口拼装名称",
            "prod_inst_num": "用户设备号",
            "update_user": "更新用户",
            "update_date": "更新时间"
        },
        cir: {
            "cir_id": "链路id",
            "cir_no": "链路编号",
            "cir_type": "链路类型",
            "cir_status": "链路状态",
            "equ_type_a": "A端设备类型",
            "equ_id_a": "A端设备id",
            "equ_name_a": "A端设备名称",
            "equ_no_a": "A端设备编码",
            "equ_region_a": "A端设备区局",
            "equ_subregion_a": "A端设备行政分局",
            "equ_site_a": "A端设备站点",
            "equ_room_a": "A端设备机房",
            "port_id_a": "A端端口id",
            "port_no_a": "A端端口编号",
            "port_name_a": "A端端口名称",
            "port_assemtcode_a": "A端端口拼装编号",
            "port_assemtname_a": "A端端口拼装名称",
            "equ_type_z": "Z端设备类型",
            "equ_id_z": "Z端设备id",
            "equ_name_z": "Z端设备名称",
            "equ_no_z": "Z端设备编码",
            "equ_region_z": "Z端设备区局",
            "equ_subregion_z": "Z端设备行政分局",
            "equ_site_z": "Z端设备站点",
            "equ_room_z": "Z端设备机房",
            "port_id_z": "Z端端口id",
            "port_no_z": "Z端端口编号",
            "port_name_z": "Z端端口名称",
            "port_assemtcode_z": "Z端端口拼装编号",
            "port_assemtname_z": "Z端端口拼装名称",
            "update_user": "更新用户",
            "update_date": "更新时间"
        },
        router: {
            "cir_id": "链路id",
            "cir_no": "链路编号",
            "rt_no": "路由序号",
            "rt_port_no_a": "路由A端设备机房地址",
            "rt_port_name_a": "路由A端设备机房",
            "rt_port_equip_a": "路由A端设备拼装编码",
            "rt_port_assemtcode_a": "路由A端端口拼装编码",
            "rt_port_no_z": "路由Z端设备机房地址",
            "rt_port_name_z": "路由Z端设备机房",
            "rt_port_equip_z": "路由Z端设备拼装编码",
            "rt_port_assemtcode_z": "路由Z端端口拼装编码",
            "link_type": "连接类型",
            "optic_no": "光缆编号",
            "optic_1": "光缆纤芯1",
            "optic_2": "光缆纤芯2",
            "cir_staus": "纤芯状态",
            "update_user": "更新用户",
            "update_date": "更新时间"
        }
    }
    function findKeyIndex(key){
        var i = 0;
        while(i < GLOBAL_KEYINFOS.length){
            if(key === GLOBAL_KEYINFOS[i].key){
                return i;
            }
            i ++;
        }
        return -1;
    }
    
    function getMappingKeys(key) {
        var i = 0,l = GLOBAL_KEYINFOS.length;
        while(i < l){
            if(GLOBAL_KEYINFOS[i].key === key){
                return GLOBAL_KEYINFOS[i].keyFields;
            }
            i ++;
        }
        return '';
    }
    
    function addIndex2Data(data){
        data.forEach(function(e,i){
            e._index = i;
            if(e.children){
                addIndex2Data(e.children);
            }
        })                                        
        return data;
    }

    function createTooltip(){
        var tooltip = document.getElementById('d3tooltip');
        if (!tooltip) {
            tooltip = document.createElement('div');
            tooltip.id = 'd3tooltip';
            document.body.appendChild(tooltip);
        }
    }
    function removeTooltip(){
        var tooltip = document.getElementById('d3tooltip');
        tooltip && document.body.removeChild(tooltip);
    }

    function searchChildrenCnt(params, callback) {
        var cql = "match (n1)-[r1:上联]->(n0{equip_no:$equip_no}) return count(distinct n1)";
        NodesREQ.send('POST', serverPath + 'db/data/transaction/commit', {
            "statements": [{
                "statement": cql,
                "parameters":params
            }]
        }, function(data) {
            /**
             * results
             * [{"columns":["count(n1)"],"data":[{"row":[27],"meta":[null]}]}]
             */
            callback && callback(data[0].row[0]);
        })
    }
    function searchChildrenGraph(params,callback){
        var cql = 'MATCH p=(s:'+ params.label+')<--(n) WHERE s.equip_no=$eno RETURN p'
        NodesREQ.send('POST', serverPath + 'db/data/transaction/commit', {
            "statements": [{
                "statement": cql,
                "parameters": params,
                "resultDataContents": ["row", "graph"]
            }]
        }, function(data) {
            if (!data.length) return;
            callback && callback(data);
        })

    }
    function searchGraphRemote(params, callback) {
        var cql;
        if(params.cir_nos){
            cql = 'match (n{equip_no:$equip_no}) optional match p1=(n0)-[r1:上联]-(b0)-[:上联*..]->(n1:bas_equip) where r1.cir_no in $cir_nos optional match p2=(n2)-[:上联]->(n1) optional match p3=(n)-[:上联*..]->(n4:bas_equip) optional match p4=(n5)-[:上联]->(n4) return p1,p2,p3,p4';
        }else{
            cql = 'match(n{equip_no:$equip_no}) optional match levelPath=(s)-->(n)-->(f) optional  match rootPath= (n)-[:上联*..6]-(root:root) return case when "prod_inst" in labels(n) then rootPath else levelPath end';
        }
        NodesREQ.send('POST', serverPath + 'db/data/transaction/commit', {
            "statements": [{
                "statement": cql,
                "parameters":params,
                "resultDataContents": ["row", "graph"]
            }]
        }, function(data) {
            if (!data.length) {
                drawGraph();
                callback && callback();
                return;
            }
            var dealedData = joinRelationInfos2Target(data,params.cir_nos);
            var childrenMaps = dealedData.childrenMaps;
            var nodesInfosMaps = dealedData.nodesInfosMaps;

            //找根节点
            var nodes = [],
                k, rootId;
            for (k in childrenMaps) {
                var e = childrenMaps[k];
                nodes = nodes.concat(e);
            }
            for (k in childrenMaps) {
                if (nodes.indexOf(k) === -1) {
                    rootId = k;
                    break;
                }
            }

            //组织树结构
            var stack = [];
            //先将根节点信息放入栈
            stack.push(nodesInfosMaps[rootId]);
            var item;

            while (stack.length) {
                item = stack.shift();
                //如果该节点还没有chilren，但childrenMaps里面有这个key，说明这个节点有子节点
                if (!item.children && childrenMaps.hasOwnProperty(item.id)) {
                    item.children = [];
                    for (var i = 0, l = childrenMaps[item.id].length; i < l; i++) {
                        var e = childrenMaps[item.id][i];
                        item.children.push(nodesInfosMaps[e]);
                        stack = [nodesInfosMaps[e]].concat(stack);
                    }
                    //排下序，保证后面加_index时的序号是正确的
                    item.children.sort(function(a, b) {
                        return a.id - b.id;
                    })
                }

            };
            var treeData = nodesInfosMaps[rootId];
            // callback && callback(treeData);
            drawGraph(addIndex2Data([treeData])[0]);
            callback && callback();
        })
    }

    //路由查询
    function searchRouter(params, callback) {
        var cql = "MATCH p=(a:rt_equip)<-[r:上联{cir_id:$cir_id}]-(c:rt_equip) return p";
        NodesREQ.send('POST', serverPath + 'db/data/transaction/commit', {
            "statements": [{
                "statement": cql,
                "parameters":params,
                "resultDataContents":['row','graph']
            }]
        }, function(data) {
            //能够正确走到这里，说正常执行
            callback && callback(data);
        })
    }

    function updateLinkRemote(params, callback) {
        var statements = [];
        var cql = "unwind $ul as row match (n1)-[r1:上联{cir_no:row[0]}]->(n0) optional match (n2)-[r2:上联*]->(n1) forEach (r in r2 | set r.cir_status=row[1])  set r1.cir_status = row[1]";
        NodesREQ.send('POST', serverPath + 'db/data/transaction/commit', {
            "statements": [{
                "statement": cql,
                "parameters":params
            }]
        }, function(data) {
            //能够正确走到这里，说正常执行
            callback && callback();
        })
    }

    function drawGraph(data){
        if(data){
            new Graph(data,$(".relation"));
            $('.control').show();
        }else{
            $('.relation').html('<p class="nodata">没有相关信息!</p>');
            $('.control').hide();
        }
    }
    //处理数据，把链接属性加到target节点上
    function joinRelationInfos2Target(data,cirNos){
        var childrenMaps = {};
        var nodesInfosMaps = {};
        var childrenNodes = [];
        data.forEach(function(e) {
            e.graph.nodes.forEach(function(_e) {
                if (!nodesInfosMaps[_e.id]) {
                    nodesInfosMaps[_e.id] = _e;
                }
            }) 
            e.graph.relationships.forEach(function(_e, _i) {
                var eid = _e.endNode;
                var sid = _e.startNode;
                if (!childrenMaps[eid]) {
                    childrenMaps[eid] = [];
                }
                if(!nodesInfosMaps[sid].relation){
                    nodesInfosMaps[sid].relation = _e.properties;
                }else{
                    if(cirNos && cirNos.indexOf(_e.properties.cir_no) > -1){
                        nodesInfosMaps[sid].relation = _e.properties;
                    }
                }
                if (childrenMaps[eid].indexOf(sid) === -1) {
                    childrenMaps[eid].push(sid);
                }
            })
        })
        return {
            childrenMaps:childrenMaps,
            nodesInfosMaps:nodesInfosMaps
        }
    }

    function showLoading(){
        $('.loading').show();
    }
    function hideLoading(){
        $('.loading').hide();
    }
    
    
    //树图
    function Graph(data,$container){
        this.data = data;
        this.$container = $container;
        this.distance = 80;
        this.init();
    }
    Graph.prototype = {
        init:function(){
            this.w = +this.$container.innerWidth()
            this.h = +this.$container.innerHeight()
            this.R = this.w >= this.h ? this.h : this.w
            this.translateX = this.w / 2
            this.translateY = this.h / 2
            this.zoom = d3.behavior.zoom().scaleExtent([.1, 10]).on("zoom", this.zoomed.bind(this))
            this.drag = d3.behavior.drag().on("dragstart", function() {
                d3.event.sourceEvent.stopPropagation()
            }).on("drag", this.draged.bind(this));
            //动画持续时间
            this.duration = 1000
            //节点编号
            this.index = 0;
            this.detailDidMount();
            this.draw();
        },
        draw:function(data){
            var that = this;
            if(data) this.data = data;
            this.$container.empty();
            //定义一个Tree对象,定义旋转角度和最大半径
            var maxDegree = 90;
            var tree = this.tree = d3.layout.tree()
                // .size([360, this.R / 2 - 120])
                .separation(function(a, b) {
                 return a.depth?(a.parent == b.parent ? 1 : 2) / a.depth:1;
                });
            //定义布局方向
            var diagonal = this.diagonal = d3.svg.diagonal()
                .projection(function(d,i) {
                    var r = d.y,
                        a = (d.x - 90) / 180 * Math.PI;
                    return [r * Math.cos(a), r * Math.sin(a)];
                });
            //新建画布，移动到圆心位置
            var svg = this.svg = d3.select(".relation").append("svg")
                .attr("width", this.w)
                .attr("height",this.R)
                .call(this.zoom)
                .call(this.drag)
                .append("g")
                .attr("transform", function(d) {
                    var isSingleChildTree = function(){
                        var stack = [];
                        stack.push(that.data);

                        var item;
                        while (stack.length) {
                            item = stack.shift();

                            if (item.children && item.children.length) {
                                stack = item.children.concat(stack);
                                if(item.children.length !== 1){
                                    return false;
                                }
                            }
                        }
                        return true;
                    }()
                    return "translate(" + that.w / 2 + "," + (isSingleChildTree?that.R/10:that.R / 2) + ")scale(1)";
                });

            this.root = this.data;
            this.root.x0 = 180;
            this.root.y0 = 0;
            that.update(this.root);
            
        },
        //更新显示
        update:function (source) {
            var that = this;
            var maxDepth = that.getMaxDepth();
            var r = maxDepth * that.distance;
            this.tree.size([360,r]);
            //取得现有的节点数据,因为设置了Children属性，没有Children的节点将被删除
            var nodes = this.tree.nodes(this.root)//.reverse();
            var links = this.tree.links(nodes);

            //set nodes fx
            nodes.forEach(function(d){
                var parent = d.parent;
                d.fy = d.depth * that.distance;
                if(!parent){//根节点
                    d.fx = d.x;
                }else{
                    var children = parent.children;
                    var len = children.length;
                    if(len === 1){
                        d.fx = d.x;
                    }else{
                        var deltaAngle = children[len -1].x - children[0].x;
                        deltaAngle = deltaAngle > CONST_MAXGANGLE?deltaAngle - CONST_MAXGANGLE:0;
                        var _mindex = Math.floor(len/2);
                        var middleAngle = children[_mindex].x;
                        var perAngle = deltaAngle/len;
                        d.fx = d.x > middleAngle? d.x - (d._index-_mindex)*perAngle:d.x + (_mindex - d._index)*perAngle;        
                   }
                }
            })


            //为节点更新数据
            var node = this.svg.selectAll("g.node")
                .data(nodes, function(d) {
                    return d.id;
                });
            //为链接更新数据
            var innerlink = this.svg.selectAll("path.innerlink").data(links, function(d) {
                return d.target.id;
            });
            //更新链接
            innerlink.enter().append("path")
                .attr("class", function(d){
                    if(d.target.relation && d.target.relation.cir_status=='未恢复'){
                        return 'innerlink badlink link '+d.target.labels[0];
                    }
                    return 'innerlink link '+d.target.labels[0];
                })
                .attr('stroke',function(t){
                    var i = findKeyIndex(t.target.labels[0]);
                    if(t.target.relation && t.target.relation.cir_status=='未恢复'){
                        return CONST_HIGHLIGHTCOLORS[0];
                    }
                    return CONST_COLORS[CONST_COLORS.length -1];
                    // return CONST_COLORS[i%CONST_COLORS.length];
                })
                .attr("d", function(d) {
                    var o = {
                        x: source.fx,
                        y:source.fy
                    };
                    return that.diagonal({
                        source: o,
                        target: o
                    });
                })
            
            innerlink.transition()
                .duration(that.duration)
                .attr("d", function(d){
                     var o = {
                         x:d.source.fx,
                         y:d.source.fy
                     }
                     var o2 = {
                         x:d.target.fx,
                         y:d.target.fy
                     }
                     return that.diagonal({
                         source:o,
                         target:o2
                     })
                 });

            //移除无用的链接
            innerlink.exit()
                .transition()
                .duration(that.duration)
                .attr("d", function(d) {
                    var o = {
                        x:source.fx,
                        y:source.fy
                    }
                    return that.diagonal({
                        source: o,
                        target: o
                    });
                })
                .remove();


            var outerlink = this.svg.selectAll("path.outerlink").data(links, function(d) {
                return d.target.id;
            });
            outerlink.enter().append("path")
                .attr("class", function(d){
                    if(d.target.relation && d.target.relation.cir_status=='未恢复'){
                        return 'outerlink link badlink'+d.target.labels[0];
                    }
                    return 'outerlink link '+d.target.labels[0];
                })
                .attr("d", function(d) {
                    var o = {
                        x: source.fx,
                        y:source.fy
                    };
                    return that.diagonal({
                        source: o,
                        target: o
                    });
                })
                .style("opacity", "0")
                .attr('stroke',function(t){
                    var i = findKeyIndex(t.target.labels[0]);
                    if(t.target.relation && t.target.relation.cir_status=='未恢复'){
                        return CONST_HIGHLIGHTCOLORS[0];
                    }
                    return CONST_COLORS[CONST_COLORS.length -1];
                    // return CONST_COLORS[i%CONST_COLORS.length];
                })
                .on('contextmenu',function(d){
                    var html = '',k;
                    var keys = GLOBAL_CIRINFOS.keyFields;
                    keys.forEach(function(e,i){
                        var field = e;
                        var fixField = GLOBAL_CIRINFOS.fixFields[e];
                        var cnDesc = GLOBAL_KEYMAPPINGS.cir[field];
                        html += cnDesc + '：' + (d.target.relation?d.target.relation[fixField || field] : '无信息') + '<br>';
                    })
                    html += '<a href="javascript:void(0)" class="showRouter" cirid="' + (d.target.relation ? d.target.relation.cir_id : '') + '" cirno="' + (d.target.relation ? d.target.relation.cir_no : '') + '">路由信息</a>'
                    layer.closeAll();
                    layer.open({
                        title:'光路信息',
                        type:1,
                        skin:'detail-win',
                        area:['300px','auto'],
                        shade:0,
                        offset:['20px',$(window).width() - 340 + 'px'],
                        content:html
                    })
                    d3.event.preventDefault();
                    d3.event.stopPropagation();
                })
                .on("mouseover", function (d) {
                    d3.select(this).style("opacity", "0.6");
                })
                .on("mouseout", function (d) {
                    d3.select(this).style("opacity", "0");
                })
                .append('title')
                .text('右键点我看链路详情...')

            
            outerlink.transition()
                .duration(that.duration)
                 .attr("d", function(d){
                     var o = {
                         x:d.source.fx,
                         y:d.source.fy
                     }
                     var o2 = {
                         x:d.target.fx,
                         y:d.target.fy
                     }
                     return that.diagonal({
                         source:o,
                         target:o2
                     })
                 });

            //移除无用的链接
            outerlink.exit()
                .transition()
                .duration(that.duration)
                .attr("d", function(d) {
                    var o = {
                        x:source.fx,
                        y:source.fy
                    }
                    return that.diagonal({
                        source: o,
                        target: o
                    });
                })
                .remove();

            //更新节点集合
            var nodeEnter = node.enter()
                .append("g")
                .attr("class", function(d){
                    return 'node ' +d.labels[0];
                })
                .attr("transform", function(d) {
                    return "rotate(" + (source.x0 - 90) + ")translate(" + source.y0 + ")";
                })
                .on("click", that.nodeClick.bind(that))
                .on('contextmenu',function(d){
                    var html ='';
                    var keys = getMappingKeys(d.labels[0]);
                    var i = 0,l = keys.length,_i = findKeyIndex(d.labels[0]);
                    that.showNodeCommonInfos(d,function(o){
                        var title = o.title;
                        var html = o.chtml;
                        if(/ipa|olt/i.test(d.labels[0])){
                            html +='<br/><a href="javascript:void(0)" class="showpplink" data-show="'+ d.labels[0] +'">设备面板图</a>'
                        }
                        layer.closeAll();
                        layer.open({
                            type:1,
                            skin:'detail-win',
                            title:title,
                            area:['300px','auto'],
                            offset:['20px',$(window).width() - 340 + 'px'],
                            content:html,
                            shade:0,
                            shadeClose:true
                        });
                    })
                    d3.event.preventDefault();
                    d3.event.stopPropagation();
                })
                
            //为节点添加圆形标记,如果有子节点为红色，否则绿色
            nodeEnter.append("circle")
                .attr('fill',function(t){
                    var i = findKeyIndex(t.labels[0]);
                    return CONST_COLORS[i%CONST_COLORS.length];
                })
                .attr("r", function(t) {
                    return t.depth? CONST_MAXR - t.depth *CONST_K:CONST_MAXR;
                })
                .on('mouseover',function(d){
                    d3.select(this).attr('r',10);
                    that.mouseover(d);
                })
                .on('mouseout',function(d){
                    d3.select(this).attr("r", d.depth? CONST_MAXR - d.depth *CONST_K:CONST_MAXR);
                    that.mouseout(d);
                });
            //为节点添加说明文字
            nodeEnter.append("text")
                .attr('class','nodelabel')
                .attr('dy','1.5em')
                .text(function(d) {
                    var i = findKeyIndex(d.labels[0]);
                    var nameKey = GLOBAL_KEYINFOS[i].value;
                    var name = d.properties[nameKey];
                    if(i < 5){
                        return name;
                    }
                    if(GLOBAL_KEYINFOS[i].name != '终端'){
                        return '';
                    }
                    name = name && name.length>5?name.substring(0,5)+'…':name;
                    return GLOBAL_KEYINFOS[i].name + '：' + name + ((d.children||d._children)?'('+ (d.children||d._children).length+')':'') ;
                })
                .attr("text-anchor", function(d) {
                    return d.fx < 180 ? "start" : "end";
                })
                .attr("transform", function(d) {
                    if(d.parent && d.parent.children.length === 1 || !d.parent){
                        return "rotate(-90)translate(-10)";
                    }
                    return d.fx < 180 ? "translate(10)" : "rotate(180)translate(-10)";
                });

            nodeEnter.append('title')
                .text('右键点我看设备详情...');

            //节点动画
            var nodeUpdate = node.transition()
                .duration(that.duration)
                .attr("transform", function(d) {
                    return 'rotate('+(d.fx-90)+')translate(' + d.fy+')';
                });
            //将无用的子节点删除
            var nodeExit = node.exit()
                .transition()
                .duration(that.duration)
                .attr("transform", function(d) {
                    return "rotate(" + (source.fx - 90) + ")translate(" + source.y + ")";
                })
                .remove();
            //记录下当前位置,为下次动画记录初始值
            nodes.forEach(function(d) {
                d.x0 = d.fx;
                d.y0 = d.fy;
            });
        },
        zoomed:function() {
           this.svg.attr("transform", "translate(" + this.translateX + "," + this.translateY + ")scale(" + d3.event.scale + ")")
        },
        draged:function(){
            var t = $($("svg g")[0]).attr("transform").split("scale")[1];
            t = t.split("(")[1], t = parseFloat(t.split(")")[0]), this.translateX = this.translateX + d3.event.dx, this.translateY = this.translateY + d3.event.dy;
            var n = "translate(" + this.translateX + "," + this.translateY + ")scale(" + t + ")";
            this.svg.attr("transform", n)
        },
        showNodeCommonInfos:function(d,callback){
            var html ='';
            var keys = getMappingKeys(d.labels[0]);
            var i = 0,l = keys.length,_i = findKeyIndex(d.labels[0]);
            var title = (d.properties[GLOBAL_KEYINFOS[_i].value]||'')+'信息';
            searchChildrenCnt({
                equip_no: d.properties.equip_no
            }, function(n) {
                html += '下联设备数：<span>'+ n +'</span><br/>';
                for(; i < l; i++){
                    var field = GLOBAL_KEYINFOS[_i].keyFields[i];
                    var fixField = GLOBAL_KEYINFOS[_i].fixFields[field];
                    html += (i>0?'<br/>':'')+ GLOBAL_KEYMAPPINGS.relation[field] + '：' + (d.properties[fixField ? fixField : field] || '');
                }
                callback && callback({title:title,chtml:html});
            })
        },
        mouseover:function(t){
            var that = this;
            createTooltip();
            var tooltip = d3.select('#d3tooltip');
            var x = d3.event.pageX;
            var y = d3.event.pageY;
            that.showNodeCommonInfos(t,function(o){
                var html = '<h4 class="tool-title">' + o.title + '</h4>' + o.chtml;
                tooltip.html(html);
                tooltip.style('left', x + 4 + 'px')
                    .style('top', y + 4 + 'px');
            })
        },
        mouseout:function (d){
            removeTooltip();
            d3.event.preventDefault();
        },
        nodeClick:function(d) {
            var that = this;
            var eno = d.properties.equip_no;
            if (d.children) {
                var existChildrenIds = [];
                d.children.forEach(function(t){
                    existChildrenIds.push(t.id);
                })
                searchChildrenCnt({equip_no:eno},function(data){
                    if(d.children.length < data){
                        searchChildrenGraph({label:d.labels[0],eno:eno},function(data){
                            var dealedData = joinRelationInfos2Target(data);
                            var childrenMaps = dealedData.childrenMaps;
                            var nodesInfosMaps = dealedData. nodesInfosMaps;
                            childrenMaps[d.id].forEach(function(t){
                                if(existChildrenIds.indexOf(t) === -1){
                                    d.children.push(nodesInfosMaps[t]);
                                }
                            });
                            d.children.sort(function(a,b){
                                return a.id - b.id;
                            })
                            addIndex2Data(d.children);
                            that.update(d);
                        })
                    }else{
                        d.children = null;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
                        that.update(d);
                    }
                })
            } else {
                searchChildrenGraph({label:d.labels[0],eno:eno},function(data){
                    var dealedData = joinRelationInfos2Target(data);
                    var childrenMaps = dealedData.childrenMaps;
                    var nodesInfosMaps = dealedData. nodesInfosMaps;
                    var childrenNodes = childrenMaps[d.id].map(function(d){
                        return nodesInfosMaps[d];
                    });
                    
                    childrenNodes.sort(function(a,b){
                        return a.id - b.id;
                    })
                    addIndex2Data(childrenNodes);
                    d.children = childrenNodes;
                    d._children = null;
                    that.update(d);
                })
            }
        },
        detailDidMount:function(){
            $('body').off('click', '.showRouter').on('click', '.showRouter', function(d) {
                var $this = $(this);
                var cirId = $this.attr('cirid');
                var cirNo = $this.attr('cirno');
                searchRouter({
                    cir_id: cirId
                }, function(data) {
                    if(!data || !data.length){
                        $('#routerDetail').html('没有路由信息！')
                    }else{
                        var dealedData = deal2ForceData(data);
                    }
                    layer.open({
                        skin: 'detail-win',
                        type: 1,
                        title: cirNo + '的路由信息',
                        content: $('#routerDetail'),
                        area: ['80%', '80%']
                    }) 
                    if(data && data.length){
                        new RouteGraph(dealedData, $('#routerDetail'));
                    }
                })
            })
            function deal2ForceData(data) {
                var i = 0,
                    l = data.length;
                var ret = {
                    nodes: [],
                    links: []
                }
                var tmpn = {};
                var tmpl = {};
                while (i < l) {
                    var graph = data[i].graph;
                    var nodes = graph.nodes;
                    var links = graph.relationships;
                    nodes.forEach(function(e, i) {
                        if (typeof tmpn[e.id] == 'undefined') {
                            ret.nodes.push(e);
                            tmpn[e.id] = ret.nodes.length - 1;
                        }
                    }) 
                    links.forEach(function(e, i) {
                        if (!tmpl[e.id]) {
                            e.source = tmpn[e.endNode];
                            e.target = tmpn[e.startNode];
                            ret.links.push(e);
                            tmpl[e.id] = true;
                        }
                    }) 
                    i++;
                }
                return ret;
            }
            $('body').off('click','.showpplink').on('click','.showpplink',function(d){
                var pic = '';
                var show = $(this).attr('data-show');
                if(/ipa/i.test(show)){
                    pic = 'img/ipa.jpg';
                }
                else if(/olt/i.test(show)){
                    pic = 'img/olt.jpg';
                }

                layer.photos({
                    photos: {
                        "title": "", //相册标题
                        "id": 123, //相册id
                        "start": 0, //初始显示的图片序号，默认0
                        "data": [   //相册包含的图片，数组格式
                            {
                              // "alt": "图片名",
                              "pid": 666, //图片id
                              "src": pic, //原图地址
                              "thumb": "" //缩略图地址
                            }
                        ]
                    },
                    anim:5,
                    shade:0,
                    closeBtn:1,
                    shadeClose:true
                })
                $('.layui-layer-imgsee .layui-layer-imgbar').css('display','none');
            });
        },
        getMaxDepth:function(){
            var depth = 1;
            var iterator = function (treeNodes) {
                if (!treeNodes || !treeNodes.length) return;

                var stack = [];

                //先将第一层节点放入栈
                for (var i = 0, len = treeNodes.length; i < len; i++) {
                    stack.push(treeNodes[i]);
                }

                var item;

                while (stack.length) {
                    item = stack.shift();

                    //如果该节点有子节点，继续添加进入栈顶
                    if (item.children && item.children.length) {
                        // len = item.children.length;
                        var idepth = (item.depth || 1) +1;
                        for (; len; len--) {
                         // stack.unshift(item.children[len - 1]);
                            item.children[len -1].depth = idepth;
                        }
                        depth = Math.max(depth,idepth);
                        stack = item.children.concat(stack);
                    }
                }
            };
            iterator([this.data]);
            return depth + 1;
        }
        
    }

    //路由图
    function RouteGraph(data, $container) {
        this.data = data;
        this.$container = $container;
        this.draw();
    }
    RouteGraph.prototype.draw = function() {
        var that = this;
        var width = that.$container.width();
        var height = that.$container.height();
        var nodeR = 10;
        var root = this.data;
        var linkTypes = ['关联', '跳接', '局向光纤'];
        this.$container.empty();
        var svg = d3.select("#routerDetail")
            .append("svg")
            .attr("width", width)
            .attr("height", height - 5 );

        var linkDistance = Math.floor((height -5)/root.links.length);

        var force = d3.layout.force()
            .nodes(root.nodes)
            .links(root.links)
            .size([width, height])
            .linkDistance(linkDistance)
            .charge(-1500)
            .start();

        var links = svg.selectAll("line")
            .data(root.links)
            .enter()
            .append("line")
            .attr('class', function(d) {
                var idx = linkTypes.indexOf(d.properties.link_type);
                return 'rlink' + idx;
            })
            .attr("stroke", colorDepends)
            .style("stroke-width", 1);

        var outerlinks = svg.selectAll(".outerline")
            .data(root.links)
            .enter()
            .append("line")
            .attr('class','olink')
            .attr("stroke", colorDepends)
            .style('opacity',0)
            .style("stroke-width", 8)
            .on('mouseover',function(d){
                d3.select(this).style('opacity',.5);
                createTooltip();
                var tooltip = d3.select('#d3tooltip');
                var x = d3.event.pageX;
                var y = d3.event.pageY;
                var keys = GLOBAL_ROUTERINFOS.keyFields;
                var i = 0,
                    l = keys.length;
                var html = '<h4 class="tool-title">光缆信息</h4>';
                for (; i < l; i++) {
                    var field = keys[i];
                    var fixField = GLOBAL_ROUTERINFOS.fixFields[field];
                    if(field.substr(-1) == 'a'){
                        html += (i > 0 ? '<br/>' : '') + GLOBAL_KEYMAPPINGS.router[field] + '：' + (d.source.properties[fixField || field] || '');
                    }else if(field.substr(-1) == 'z'){
                        html += (i > 0 ? '<br/>' : '') + GLOBAL_KEYMAPPINGS.router[field] + '：' + (d.target.properties[fixField || field] || '');
                    }else{
                        html += (i > 0 ? '<br/>' : '') + GLOBAL_KEYMAPPINGS.router[field] + '：' + (d.properties[fixField || field] || '');
                    }
                }
                tooltip.html(html);
                tooltip.style('left', x + 4 + 'px').style('top', y + 4 + 'px');
            })
            .on('mouseout',function(d){
                d3.select(this).style('opacity',0);
                removeTooltip();
                d3.event.preventDefault();
            });

        var texts = svg.selectAll(".linetext")
            .data(root.links)
            .enter()
            .append("text")
            .attr("class","linetext")
            .attr("fill", colorDepends)
            .text(function(d){
                return d.properties.link_type;
            });

        var drag = force.drag().on("dragstart", function(d, i) {
            d.fixed = true;
        })

        var nodes = svg.selectAll("circle")
            .data(root.nodes)
            .enter()
            .append("circle")
            .attr("class", "node")
            .attr("r", nodeR)
            .attr("fill", function(d) {
                return '#0f9561';
            })
            .on("mouseover", function(d, i) {
                var that = this;
                var keys = GLOALROUTERNODES.keyFields;
                createTooltip();
                var tooltip = d3.select('#d3tooltip');
                var x = d3.event.pageX;
                var y = d3.event.pageY;
                var i = 0,
                    l = keys.length;
                var suffix = "_a";//为了取字段中文
                var html = '<h4 class="tool-title">路由端点信息</h4>';
                for (; i < l; i++) {
                    var field = keys[i];
                    html += (i > 0 ? '<br/>' : '') + GLOBAL_KEYMAPPINGS.router[field + suffix].substr(4) + '：' + (d.properties[field] || '');
                }
                tooltip.html(html);
                tooltip.style('left', x + 4 + 'px').style('top', y + 4 + 'px');
            })
            .on("mouseout", function(d, i) {
                removeTooltip();
                d3.event.preventDefault();
            })
            .on("dblclick", function(d, i) {
                d.fixed = false;
            })
            .call(drag);

        var nodesLabels = svg.selectAll(".nodetext")
            .data(root.nodes)
            .enter()
            .append('text')
            .attr("dy", "-1.5em")
            .attr("class","nodetext")
            .style("text-anchor", "middle")
            .text(function(d) {
                return d.properties.rt_port_equip;
            });


        force.on("tick", function() {
            //限制结点的边界
            root.nodes.forEach(function(d, i) {
                d.x = d.x - nodeR / 2 < 0 ? nodeR / 2 : d.x;
                d.x = d.x + nodeR / 2 > width ? width - nodeR / 2 : d.x;
                d.y = d.y - nodeR / 2 < 0 ? nodeR / 2 : d.y;
                d.y = d.y + nodeR / 2 > height ? height - nodeR / 2 : d.y;
            });

            //更新连接线的位置
            links
                .attr("x1", function(d) {
                    return d.source.x;
                })
                .attr("y1", function(d) {
                    return d.source.y;
                })
                .attr("x2", function(d) {
                    return d.target.x;
                })
                .attr("y2", function(d) {
                    return d.target.y;
                });

            outerlinks
                .attr("x1", function(d) {
                    return d.source.x;
                })
                .attr("y1", function(d) {
                    return d.source.y;
                })
                .attr("x2", function(d) {
                    return d.target.x;
                })
                .attr("y2", function(d) {
                    return d.target.y;
                });

            //更新连接线上文字的位置
            texts
                .attr("x",function(d){ 
                    return (d.source.x + d.target.x) / 2 ; 
                })
                .attr("y",function(d){ 
                    return (d.source.y + d.target.y) / 2 ; 
                });

            //更新结点图片和文字
            nodes
                .attr("cx", function(d) {
                    return d.x;
                })
                .attr("cy", function(d) {
                    return d.y;
                });

            nodesLabels
                .attr("x", function(d) {
                    return d.x;
                })
                .attr("y", function(d) {
                    return d.y;
                });
        })

        function colorDepends(d){
            var idx = linkTypes.indexOf(d.properties.link_type);
            if(d.properties.optic_status != '已恢复'){
                return HIGHLIGHTCOLOR[1];
            }
            return CONST_COLORS2[idx % CONST_COLORS2.length];
        }
    }


    function initPage() {
        var equipNo = getUrlParamValue('eno');
        var ul = getUrlParamValue('ul');
        var w = document.body.clientWidth;
        var h = document.body.clientHeight;
        $(".relation").width(w);
        $(".relation").height(h);
        showLoading();
        //更新操作
        if (ul) {
            var loopArr = ul.split(';');
            var loopLen = loopArr.length;
            var i= 0;
            var params = {};
            var statusMap = {
                "0":'未恢复',
                "1":'已恢复'
            }
            var cir_nos = [];
            params.equip_no = equipNo;
            params.ul = [];
            for(;i< loopLen;i++){
                var a = loopArr[i].split(',');
                a[1] = statusMap[a[1]];
                cir_nos.push(a[0]); 
                params.ul.push(a);
            }
            updateLinkRemote(params, function() {
                if (equipNo) {
                    searchGraphRemote({
                        "equip_no": equipNo,
                        'cir_nos':cir_nos
                    }, hideLoading);
                } else {
                    drawGraph();
                }
            });
            return;
        }
        //查询
        if (equipNo) {
            searchGraphRemote({
                equip_no: equipNo
            }, hideLoading);
        }else{
            hideLoading();
            drawGraph();
        }
    }
    initPage();
})();